package section_4_3;

import javax.swing.JFrame;

/**
   This program displays the growth of an investment, showing
   a bar chart.
*/
public class InvestmentViewer4
{  
   public static void main(String[] args)
   {  
      JFrame frame = new InvestmentFrame4();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
   }
}
